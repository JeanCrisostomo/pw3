package br.com.caffeinetime.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import br.com.caffeinetime.R;
import br.com.caffeinetime.model.Bebidas;
import br.com.caffeinetime.model.Snacks;
import br.com.caffeinetime.view.BebidasActivity;
import br.com.caffeinetime.view.SnacksActivity;

public class BebidasLinhaConsultaAdapter extends BaseAdapter {

    //Cria objeto LayoutInflater para ligar com a View activity_linha_bebidas.xml
    private static LayoutInflater layoutInflater = null;
    List<Bebidas> bebidas =  new ArrayList<>();

    //Cria objeto do tipo que lista os bebidas
    private BebidasActivity listarBebidas;

    //Construtor que recebe snacks como parametro e a lista de bebidas que vai retornar do BD
    public BebidasLinhaConsultaAdapter(BebidasActivity listarBebidas, List<Bebidas> bebidas ) {
        this.bebidas =  bebidas;
        this.listarBebidas  =  listarBebidas;
        this.layoutInflater = (LayoutInflater) this.listarBebidas.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    //Retorna a quantidade de objetos que esta na lista
    @Override
    public int getCount(){
        return bebidas.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    //Método converte os valores de um item  da lista de Snacks para uma linha do ListView
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //Cria um objeto para acessar o layout activity_linha_bebidas.xml
        final View viewLinhaLista = layoutInflater.inflate(R.layout.activity_linha_bebidas,null);

        //vincula os campos do arquivo de layout aos objetos cadastrados
        TextView textViewNome  =  viewLinhaLista.findViewById(R.id.textViewNome);
        TextView textViewValor = viewLinhaLista.findViewById(R.id.textViewValor);
        TextView textViewDescricao = viewLinhaLista.findViewById(R.id.textViewDescricao);

        textViewNome.setText(String.valueOf(bebidas.get(position).getNome()));
        textViewValor.setText(String.valueOf(bebidas.get(position).getValor()));
        textViewDescricao.setText(bebidas.get(position).getDescricao());

        return viewLinhaLista;
    }
}

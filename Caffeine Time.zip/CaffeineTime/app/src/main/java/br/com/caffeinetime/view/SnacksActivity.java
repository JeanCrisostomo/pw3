package br.com.caffeinetime.view;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import br.com.caffeinetime.R;
import br.com.caffeinetime.adapter.SnacksLinhaConsultaAdapter;
import br.com.caffeinetime.model.Snacks;

public class SnacksActivity extends AppCompatActivity {
    private ListView listSnacks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_snacks);
        listSnacks = this.findViewById(R.id.listViewSnacks);
        getAll(Snacks.getAll());
    }
    protected  void getAll(List<Snacks> snacks){
        listSnacks.setAdapter(new SnacksLinhaConsultaAdapter(this, snacks));
    }
}
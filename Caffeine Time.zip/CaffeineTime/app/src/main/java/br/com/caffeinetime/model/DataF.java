package br.com.caffeinetime.model;

import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

@RequiresApi(api = Build.VERSION_CODES.N)
public class DataF {

    /*@RequiresApi(api = Build.VERSION_CODES.O)
    public static String formatarDataString(Date data){
        String d = data.toString().DateFormat.("dd/MM/yyyy");
        return d;
    }*/


    public static String formatarDataString(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String data = null;
        data = sdf.format(date);
        return data;
    }

    public static Date formatarDataDate(String date){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date data = null;
        try {
            data = sdf.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return data;
    }
}
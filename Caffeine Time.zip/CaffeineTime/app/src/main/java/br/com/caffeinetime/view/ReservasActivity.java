package br.com.caffeinetime.view;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;
import br.com.caffeinetime.R;
import br.com.caffeinetime.model.DataF;
import br.com.caffeinetime.model.HoraF;
import br.com.caffeinetime.model.Reservas;

public class ReservasActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText nomeAct;
    private EditText emailAct;
    private EditText pessoasAct;
    private EditText mensagemAct;
    private EditText dataAct;
    private EditText horaAct;
    private Button btnReservar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservas);
        nomeAct = findViewById(R.id.txtNome);
        emailAct = findViewById(R.id.txtEmail);
        pessoasAct = findViewById(R.id.quantPessoas);
        mensagemAct = findViewById(R.id.txtMensagem);
        dataAct = findViewById(R.id.txtData);
        horaAct = findViewById(R.id.txtHora);
        btnReservar = findViewById(R.id.btnReservar);
        btnReservar.setOnClickListener(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onClick(View view) {
        //quando clica no botão reservar entra nesse método
        int id = 0;
        id++; //controlando o id das reservas
        String nome = nomeAct.getText().toString();
        String email = emailAct.getText().toString();
        int quantPessoas = Integer.parseInt(pessoasAct.getText().toString());
        String mensagem = mensagemAct.getText().toString();
        String data = dataAct.getText().toString();
        String hora = horaAct.getText().toString();

        Reservas reserva = new Reservas(id, DataF.formatarDataDate(data), HoraF.formatarHoraDate(hora), nome, mensagem, quantPessoas, email);

    }

}

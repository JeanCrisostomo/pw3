package br.com.caffeinetime.model;

import java.util.ArrayList;
import java.util.List;

public class Snacks {
    private int id;
    private int estoque;
    private float valor;
    private String nome;
    private String descricao;
    private boolean vegetariano;
    private boolean vegano;
    private boolean semGluten;
    private boolean semLactose;

    public Snacks(){}
    public Snacks(int id){
        this.id = id;
    }
    public Snacks(int id, int quantidade, float valor, String nome, String descricao, boolean vegetariano, boolean vegano, boolean semGluten, boolean semLactose){
        this.id = id;
        this.estoque+=quantidade;
        this.valor = valor;
        this.nome = nome;
        this.descricao = descricao;
        this.vegetariano = vegetariano;
        this.vegano = vegano;
        this.semGluten = semGluten;
        this.semLactose = semLactose;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public boolean isVegetariano() {
        return vegetariano;
    }

    public void setVegetariano(boolean vegetariano) {
        this.vegetariano = vegetariano;
    }

    public boolean isVegano() {
        return vegano;
    }

    public void setVegano(boolean vegano) {
        this.vegano = vegano;
    }

    public boolean isSemGluten() {
        return semGluten;
    }

    public void setSemGluten(boolean semGluten) {
        this.semGluten = semGluten;
    }

    public boolean isSemLactose() {
        return semLactose;
    }

    public void setSemLactose(boolean semLactose) {
        this.semLactose = semLactose;
    }

    public static List<Snacks> getAll(){
        ArrayList<Snacks> snacks = new ArrayList<>();
        snacks.add(new Snacks(1, 30, 5.0f, "Torta de chocolate floresta negra", "Fatia de torta de chocolate amargo com recheio de frutas vermelhas.",
                true, false, false, false));
        snacks.add(new Snacks(2, 70, 3.0f, "Brigadeiro de chocolate ao leite com confeitos", "Brigadeiro de festa tradicional.",
                true, false, false, false));
        snacks.add(new Snacks(3, 70, 3.0f, "Brigadeiro de cacau com confeitos", "Brigadeiro vegano, sem glúten e sem lactose.",
                true, true, true, true));
        snacks.add(new Snacks(4, 70, 3.0f, "Donut", "Donut tradicional com cobertura de limão siciliano.",
                true, false, false, false));
        snacks.add(new Snacks(5, 50, 5.0f, "Brownie", "Brownie de cacau com nozes vegano, sem glúten e sem lactose.",
                true, false, false, false));
        snacks.add(new Snacks(6, 20, 8.0f, "Torta de frango", "Fatia de torta de frango desfiado.",
                false, false, false, false));
        snacks.add(new Snacks(7, 20, 8.0f, "Torta de palmito", "Fatia de torta de palmito vegana, sem glúten e sem lactose.",
                true, true, true, true));
        snacks.add(new Snacks(8, 30, 5.90f, "Empada de carne", "Empada de carne bovina.",
                false, false, false, false));
        snacks.add(new Snacks(9, 80, 3.90f, "Pão de queijo", "Pão de queijo crocante.",
                true, false, false, false));
        snacks.add(new Snacks(10, 60, 2.50f, "Pão com manteiga", "Pão francês com manteiga quente na chapa.",
                true, false, false, false));
        return snacks;
    }
}

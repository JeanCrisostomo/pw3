package br.com.caffeinetime.view;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import br.com.caffeinetime.R;
import br.com.caffeinetime.adapter.BebidasLinhaConsultaAdapter;
import br.com.caffeinetime.adapter.SnacksLinhaConsultaAdapter;
import br.com.caffeinetime.model.Bebidas;
import br.com.caffeinetime.model.Snacks;

public class BebidasActivity extends AppCompatActivity {
    private ListView listBebidas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_bebidas);
        listBebidas = this.findViewById(R.id.listViewBebidas);
        getAll(Bebidas.getAll());
    }
    protected  void getAll(List<Bebidas> bebidas){
        listBebidas.setAdapter(new BebidasLinhaConsultaAdapter(this, bebidas));
    }
}


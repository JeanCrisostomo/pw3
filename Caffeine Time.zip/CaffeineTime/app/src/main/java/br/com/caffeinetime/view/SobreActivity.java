package br.com.caffeinetime.view;

import android.os.Bundle;
import android.webkit.WebView;

import androidx.appcompat.app.AppCompatActivity;

import br.com.caffeinetime.R;

public class SobreActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobre);
        //usei o webview para deixar o Sobre mais bonito.
        WebView mWebView = findViewById(R.id.textView);
        String text = "<html><body>"
                + "<p align=\"justify\">"
                + getString(R.string.textoSobre)
                + "</p> "
                + "</body></html>";
        mWebView.loadData(text, "text/html", "utf-8");
    }
}
package br.com.caffeinetime.model;

import android.icu.text.SimpleDateFormat;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.text.ParseException;
import java.util.Date;

@RequiresApi(api = Build.VERSION_CODES.N)
public class HoraF {

    public static String formatarHoraString(Date hour){
        SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
        String hora = null;
        hora = sdf.format(hour);
        return hora;

    }

    public static Date formatarHoraDate(String hour){
        SimpleDateFormat sdf = new SimpleDateFormat("HH-mm");
        Date hora = null;
        try {
            hora = sdf.parse(hour);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return hora;
    }


}

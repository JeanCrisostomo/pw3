package br.com.caffeinetime.model;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.Date;

public class Reservas {
    private int id;
    private Date data;
    private Date hora;
    private String nome;
    private String mensagem;
    private int quantidadePessoas;
    private String email;


    public Reservas(){}
    public Reservas(int id){
        this.id = id;
    }
    public Reservas(int id, Date data, Date hora, String nome, String mensagem, int quantidadePessoas, String email){
        this.id = id;
        this.data = data;
        this.hora = hora;
        this.nome = nome;
        this.mensagem = mensagem;
        this.quantidadePessoas = quantidadePessoas;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Date getHora() {
        return hora;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public int getQuantidadePessoas() {
        return quantidadePessoas;
    }

    public void setQuantidadePessoas(int quantidadePessoas) {
        this.quantidadePessoas = quantidadePessoas;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public String toString() {
        return "Reserva: " + "id: " + id +
                ", data: " + DataF.formatarDataString(data) +
                ", hora: " + HoraF.formatarHoraString(hora) +
                ", nome: '" + nome + '\'' +
                ", mensagem: '" + mensagem + '\'' +
                ", quantidadePessoas: " + quantidadePessoas +
                ", email: " + email;
    }
}

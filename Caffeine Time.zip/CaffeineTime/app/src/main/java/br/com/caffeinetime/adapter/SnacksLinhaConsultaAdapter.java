package br.com.caffeinetime.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import br.com.caffeinetime.R;
import br.com.caffeinetime.model.Snacks;
import br.com.caffeinetime.view.SnacksActivity;

public class SnacksLinhaConsultaAdapter extends BaseAdapter {

    //Cria objeto LayoutInflater para ligar com a View activity_linha_snacks.xml
    private static LayoutInflater layoutInflater = null;
    List<Snacks> snacks =  new ArrayList<>();

    //Cria objeto do tipo que lista os snacks
    private SnacksActivity listarSnacks;

    //Construtor que recebe snacks como parametro e a lista de snacks que vai retornar do BD
    public SnacksLinhaConsultaAdapter(SnacksActivity listarSnacks, List<Snacks> snacks ) {
        this.snacks =  snacks;
        this.listarSnacks  =  listarSnacks;
        this.layoutInflater = (LayoutInflater) this.listarSnacks.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    //Retorna a quantidade de objetos que esta na lista
    @Override
    public int getCount(){
        return snacks.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    //Método converte os valores de um item  da lista de Snacks para uma linha do ListView
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //Cria um objeto para acessar o layout activity_linha_snacks.xml
        final View viewLinhaLista = layoutInflater.inflate(R.layout.activity_linha_snacks,null);

        //vincula os campos do arquivo de layout aos objetos cadastrados
        TextView textViewNome  =  viewLinhaLista.findViewById(R.id.textViewNome);
        TextView textViewValor = viewLinhaLista.findViewById(R.id.textViewValor);
        TextView textViewDescricao = viewLinhaLista.findViewById(R.id.textViewDescricao);

        textViewNome.setText(String.valueOf(snacks.get(position).getNome()));
        textViewValor.setText(String.valueOf(snacks.get(position).getValor()));
        textViewDescricao.setText(snacks.get(position).getDescricao());

        return viewLinhaLista;
    }
}

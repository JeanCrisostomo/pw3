    package br.com.caffeinetime.view;

    import androidx.appcompat.app.AppCompatActivity;

    import android.app.SearchManager;
    import android.content.Intent;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.AdapterView;
    import android.widget.ArrayAdapter;
    import android.widget.Button;
    import android.widget.ListView;
    import br.com.caffeinetime.R;

        public class MainActivity extends AppCompatActivity implements View.OnClickListener {
            private Button btnReservas;
            private Button btnBebidas;
            private Button btnSnacks;
            private Button btnSobre;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);
                btnReservas = findViewById(R.id.btnReservas);
                btnBebidas = findViewById(R.id.btnBebidas);
                btnSnacks = findViewById(R.id.btnSnacks);
                btnSobre = findViewById(R.id.btnSobre);
                btnReservas.setOnClickListener(this);
                btnBebidas.setOnClickListener(this);
                btnSnacks.setOnClickListener(this);
                btnSobre.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.btnReservas:
                        Intent intent1 = new Intent(this, ReservasActivity.class);
                        startActivity(intent1);
                        break;

                    case R.id.btnBebidas:
                        Intent intent2 = new Intent(this, BebidasActivity.class);
                        startActivity(intent2);
                        break;
                    case R.id.btnSnacks:
                        Intent intent3 = new Intent(this, SnacksActivity.class);
                        startActivity(intent3);
                        break;
                    case R.id.btnSobre:
                        Intent intent4 = new Intent(this, SobreActivity.class);
                        startActivity(intent4);
                        break;
                }
                /*if () {//componente bebidas
                    Intent intent = new Intent(this, BebidasActivity.class);
                    startActivity(intent);
                }
                if (position == 1) {//componente snacks
                    Intent intent = new Intent(this, SnacksActivity.class);
                    startActivity(intent);
                }
                if (position == 2) {//componente reservas
                    Intent intent = new Intent(this, ReservasActivity.class);
                    startActivity(intent);
                }
                if (position == 3) {//componente sobre
                    Intent intent = new Intent(this, SobreActivity.class);
                    startActivity(intent);
                }*/
            }


            @Override
            public void onPointerCaptureChanged(boolean hasCapture) {

            }
        }
package br.com.caffeinetime.model;

import java.util.ArrayList;
import java.util.List;

public class Bebidas {
    private int id;
    private int estoque;
    private float valor;
    private String nome;
    private String descricao;
    private boolean vegetariano;
    private boolean vegano;
    private boolean semGluten;
    private boolean semLactose;
    private boolean acucar;
    private boolean adocante;

    public Bebidas(){}
    public Bebidas(int id){
        this.id = id;
    }
    public Bebidas(int id, int quantidade, float valor, String nome, String descricao, boolean acucar, boolean adocante, boolean vegetariano, boolean vegano,
                   boolean semGluten, boolean semLactose){
        this.id = id;
        this.estoque+=quantidade;
        this.valor = valor;
        this.nome = nome;
        this.descricao = descricao;
        this.acucar = acucar;
        this.adocante = adocante;
        this.vegetariano = vegetariano;
        this.vegano = vegano;
        this.semGluten = semGluten;
        this.semLactose = semLactose;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public boolean isVegetariano() {
        return vegetariano;
    }

    public void setVegetariano(boolean vegetariano) {
        this.vegetariano = vegetariano;
    }

    public boolean isVegano() {
        return vegano;
    }

    public void setVegano(boolean vegano) {
        this.vegano = vegano;
    }

    public boolean isSemGluten() {
        return semGluten;
    }

    public void setSemGluten(boolean semGluten) {
        this.semGluten = semGluten;
    }

    public boolean isSemLactose() {
        return semLactose;
    }

    public void setSemLactose(boolean semLactose) {
        this.semLactose = semLactose;
    }

    public boolean isAcucar() {
        return acucar;
    }

    public void setAcucar(boolean acucar) {
        this.acucar = acucar;
    }

    public boolean isAdocante() {
        return adocante;
    }

    public void setAdocante(boolean adocante) {
        this.adocante = adocante;
    }

    public static List<Bebidas> getAll(){
        ArrayList<Bebidas> bebidas = new ArrayList<>();
        bebidas.add(new Bebidas(1, 16, 5.50f, "Café Espresso", "Do italiano “espremido, pressionado”, " +
                "feito em poucos segundos sob alta pressão de água na temperatura de consumo." +
                " Isso faz com que acumule muito sabor e intensidade", true, true, true, true, false, false));
        bebidas.add(new Bebidas(2, 15, 7.90f, "Macchiato", "Consiste em uma dose de espresso coberta com uma dose de leite vaporizado " +
                "(ou em espuma) sobre o café.", false, false, true, false, true, false));
        bebidas.add(new Bebidas(3, 40, 3.0f, "Ristretto", "Uma versão mais concentrada do café espresso padrão. Apresentando maior intensidade, " +
                "utiliza apenas metade da quantidade de água de um espresso.", false, false, true, true, true, true));
        bebidas.add(new Bebidas(4, 20, 7.0f, "Latte", "Leite vaporizado misturado a uma dose de café espresso, além de 1 centímetro de espuma de leite" +
                " servido sobre a bebida.", false, false, true, false, true, false));
        bebidas.add(new Bebidas(5, 27, 8.50f, "Cappuccino", "Inclui uma dose de café espresso misturado com leite vaporizado, espuma de leite e chocolate" +
                " em pequenos pedaços sobre a bebida.", false, false, true, false, false, false));
        bebidas.add(new Bebidas(6, 50, 10.0f, "Mocha", "Feito a partir da mistura do chocolate em pó com uma dose de espresso, adicionando leite " +
                "vaporizado e espuma de leite. Enfeitado com pequenos pedaços de chocolate. ", false, false, true, false, false, false));
        bebidas.add(new Bebidas(7, 34, 12.50f, "Affogato", "Sorvete de baunilha com duas doses de café espresso. ", false, false, true, false, false, false));
        bebidas.add(new Bebidas(8, 21, 8.90f, "Chocolate quente", "Mistura do chocolate em pó com leite vaporizado, espuma de leite e " +
                "pequenos pedaços de chocolate. ", false, false, true, false, false, false));
        bebidas.add(new Bebidas(9, 60, 2.50f, "Água mineral sem gás", "Água mineral sem gás Bonafonte 350Ml" , false, false, true, true, true, true));
        bebidas.add(new Bebidas(10, 60, 2.50f, "Água mineral com gás", "Água mineral com gás Bonafonte 350Ml" , false, false, true, true, true, true));
        return bebidas;
    }
}
